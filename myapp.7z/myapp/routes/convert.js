var express = require('express');
var router = express.Router();

/* GET convert listing. */
router.get('/', function(req, res, next) {
  res.render('convert', { title: "Convert Page "});
});


module.exports = router;
